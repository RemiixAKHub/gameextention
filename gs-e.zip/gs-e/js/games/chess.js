// chess.js — Full Chess implementation
// Click piece to select, click destination to move.
// Includes: legal move generation, check/checkmate/stalemate, castling, en passant, pawn promotion.
// Plays against a minimax AI (depth 3).

const GameChess = (() => {
  const STORAGE_KEY = 'game_chess';
  const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

  let board = [];
  let turn = 'w';
  let castling = '';
  let enPassant = null;
  let selected = null;
  let legalMoves = [];
  // STATUS: '' | 'check' | 'checkmate' | 'stalemate'
  // IMPORTANT: 'check' must NOT prevent the AI from moving — only 'checkmate'/'stalemate' end the game
  let status = '';
  let moveHistory = [];
  let promotionPending = null;
  let container = null;
  let thinking = false;
  let aiTimer = null;

  const PIECE_UNICODE = {
    K:'♔', Q:'♕', R:'♖', B:'♗', N:'♘', P:'♙',
    k:'♚', q:'♛', r:'♜', b:'♝', n:'♞', p:'♟',
  };

  const PIECE_VALUES = { p:100, n:320, b:330, r:500, q:900, k:20000 };

  // ── Helpers ───────────────────────────────────────────────────────────────
  function color(p)       { return p ? (p === p.toUpperCase() ? 'w' : 'b') : null; }
  function isWhite(p)     { return p && p === p.toUpperCase(); }
  function enemy(p, side) { return p && color(p) !== side; }
  function inBounds(r, c) { return r >= 0 && r < 8 && c >= 0 && c < 8; }
  function isGameOver()   { return status === 'checkmate' || status === 'stalemate'; }

  // ── State ─────────────────────────────────────────────────────────────────
  function serialize() {
    return { board, turn, castling, enPassant, status, moveHistory };
  }

  async function saveState() {
    Storage.saveLazy(STORAGE_KEY, serialize());
  }

  async function loadState() {
    const s = await Storage.load(STORAGE_KEY);
    if (s && s.board) {
      board = s.board; turn = s.turn; castling = s.castling;
      enPassant = s.enPassant; status = s.status || '';
      moveHistory = s.moveHistory || [];
      return true;
    }
    return false;
  }

  // ── FEN parsing ───────────────────────────────────────────────────────────
  function parseFen(fen) {
    const parts = fen.split(' ');
    board = [];
    for (const row of parts[0].split('/')) {
      const r = [];
      for (const ch of row) {
        if (/\d/.test(ch)) for (let i = 0; i < parseInt(ch); i++) r.push('');
        else r.push(ch);
      }
      board.push(r);
    }
    turn      = parts[1] || 'w';
    castling  = parts[2] || '';
    const ep  = parts[3];
    enPassant = (ep && ep !== '-') ? algebraicToRC(ep) : null;
  }

  function algebraicToRC(sq) {
    return [8 - parseInt(sq[1]), sq.charCodeAt(0) - 97];
  }

  // ── Move generation ───────────────────────────────────────────────────────
  function rawMoves(b, r, c, side, ep, cas) {
    const p = b[r][c];
    if (!p || color(p) !== side) return [];
    const moves = [];
    const pt  = p.toLowerCase();
    const dir = side === 'w' ? -1 : 1;
    const add = (tr, tc, special) => {
      if (inBounds(tr, tc)) moves.push({ from:[r,c], to:[tr,tc], special: special || '' });
    };

    if (pt === 'p') {
      if (inBounds(r+dir,c) && !b[r+dir][c]) {
        add(r+dir, c);
        const startRow = side === 'w' ? 6 : 1;
        if (r === startRow && !b[r+2*dir][c]) add(r+2*dir, c, 'double');
      }
      for (const dc of [-1, 1]) {
        const tr = r+dir, tc = c+dc;
        if (inBounds(tr,tc)) {
          if (enemy(b[tr][tc], side))             add(tr, tc);
          if (ep && ep[0]===tr && ep[1]===tc)     add(tr, tc, 'ep');
        }
      }
    } else if (pt === 'n') {
      for (const [dr,dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
        const tr=r+dr, tc=c+dc;
        if (inBounds(tr,tc) && color(b[tr][tc])!==side) add(tr, tc);
      }
    } else if (pt === 'b' || pt === 'r' || pt === 'q') {
      const dirs = pt==='b' ? [[-1,-1],[-1,1],[1,-1],[1,1]]
                 : pt==='r' ? [[-1,0],[1,0],[0,-1],[0,1]]
                 :             [[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]];
      for (const [dr,dc] of dirs) {
        let tr=r+dr, tc=c+dc;
        while (inBounds(tr,tc)) {
          if (!b[tr][tc]) { add(tr,tc); tr+=dr; tc+=dc; }
          else { if (enemy(b[tr][tc],side)) add(tr,tc); break; }
        }
      }
    } else if (pt === 'k') {
      for (const [dr,dc] of [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]]) {
        const tr=r+dr, tc=c+dc;
        if (inBounds(tr,tc) && color(b[tr][tc])!==side) add(tr,tc);
      }
      if (cas) {
        if (side==='w' && r===7 && c===4) {
          if (cas.includes('K') && !b[7][5] && !b[7][6] && b[7][7]==='R') add(7,6,'castle-k');
          if (cas.includes('Q') && !b[7][3] && !b[7][2] && !b[7][1] && b[7][0]==='R') add(7,2,'castle-q');
        }
        if (side==='b' && r===0 && c===4) {
          if (cas.includes('k') && !b[0][5] && !b[0][6] && b[0][7]==='r') add(0,6,'castle-k');
          if (cas.includes('q') && !b[0][3] && !b[0][2] && !b[0][1] && b[0][0]==='r') add(0,2,'castle-q');
        }
      }
    }
    return moves;
  }

  function findKing(b, side) {
    const k = side==='w' ? 'K' : 'k';
    for (let r=0; r<8; r++) for (let c=0; c<8; c++) if (b[r][c]===k) return [r,c];
    return null;
  }

  function isAttacked(b, r, c, bySide) {
    for (let sr=0; sr<8; sr++)
      for (let sc=0; sc<8; sc++)
        if (color(b[sr][sc])===bySide)
          if (rawMoves(b,sr,sc,bySide,null,'').some(m=>m.to[0]===r&&m.to[1]===c)) return true;
    return false;
  }

  function inCheck(b, side) {
    const k = findKing(b, side);
    return k ? isAttacked(b, k[0], k[1], side==='w'?'b':'w') : false;
  }

  function applyMove(b, move, cas, ep) {
    const nb = b.map(r=>[...r]);
    const { from:[fr,fc], to:[tr,tc], special } = move;
    let p = nb[fr][fc];
    nb[fr][fc] = '';
    if (p.toLowerCase()==='p' && (tr===0||tr===7)) p = p==='P'?'Q':'q'; // default promo
    nb[tr][tc] = p;
    if (special==='ep')       nb[fr][tc] = '';
    if (special==='castle-k') { nb[tr][tc-1]=nb[tr][tc+1]; nb[tr][tc+1]=''; }
    if (special==='castle-q') { nb[tr][tc+1]=nb[tr][tc-2]; nb[tr][tc-2]=''; }
    let newCas = cas;
    if (p==='K') newCas=newCas.replace('K','').replace('Q','');
    if (p==='k') newCas=newCas.replace('k','').replace('q','');
    if (fr===7&&fc===0) newCas=newCas.replace('Q','');
    if (fr===7&&fc===7) newCas=newCas.replace('K','');
    if (fr===0&&fc===0) newCas=newCas.replace('q','');
    if (fr===0&&fc===7) newCas=newCas.replace('k','');
    const newEp = (p.toLowerCase()==='p'&&Math.abs(tr-fr)===2) ? [(fr+tr)/2, fc] : null;
    return { board: nb, castling: newCas, enPassant: newEp };
  }

  function getLegalMoves(b, side, ep, cas) {
    const moves = [];
    for (let r=0; r<8; r++)
      for (let c=0; c<8; c++)
        if (color(b[r][c])===side)
          for (const move of rawMoves(b,r,c,side,ep,cas)) {
            // Castling: king can't be in check or pass through attacked square
            if (move.special?.startsWith('castle')) {
              if (inCheck(b, side)) continue;
              const midC = move.special==='castle-k' ? 5 : 3;
              const kingR = side==='w' ? 7 : 0;
              if (isAttacked(b, kingR, midC, side==='w'?'b':'w')) continue;
            }
            const { board: nb } = applyMove(b, move, cas, ep);
            if (!inCheck(nb, side)) moves.push(move);
          }
    return moves;
  }

  // ── AI ─────────────────────────────────────────────────────────────────────

  // Piece-square tables for positional evaluation
  const PST = {
    p: [ 0, 0, 0, 0, 0, 0, 0, 0,
         50,50,50,50,50,50,50,50,
         10,10,20,30,30,20,10,10,
         5, 5,10,25,25,10, 5, 5,
         0, 0, 0,20,20, 0, 0, 0,
         5,-5,-10,0, 0,-10,-5,5,
         5,10,10,-20,-20,10,10,5,
         0, 0, 0, 0, 0, 0, 0, 0],
    n: [-50,-40,-30,-30,-30,-30,-40,-50,
        -40,-20,  0,  0,  0,  0,-20,-40,
        -30,  0, 10, 15, 15, 10,  0,-30,
        -30,  5, 15, 20, 20, 15,  5,-30,
        -30,  0, 15, 20, 20, 15,  0,-30,
        -30,  5, 10, 15, 15, 10,  5,-30,
        -40,-20,  0,  5,  5,  0,-20,-40,
        -50,-40,-30,-30,-30,-30,-40,-50],
    b: [-20,-10,-10,-10,-10,-10,-10,-20,
        -10,  0,  0,  0,  0,  0,  0,-10,
        -10,  0,  5, 10, 10,  5,  0,-10,
        -10,  5,  5, 10, 10,  5,  5,-10,
        -10,  0, 10, 10, 10, 10,  0,-10,
        -10, 10, 10, 10, 10, 10, 10,-10,
        -10,  5,  0,  0,  0,  0,  5,-10,
        -20,-10,-10,-10,-10,-10,-10,-20],
    r: [ 0, 0, 0, 0, 0, 0, 0, 0,
         5,10,10,10,10,10,10, 5,
        -5, 0, 0, 0, 0, 0, 0,-5,
        -5, 0, 0, 0, 0, 0, 0,-5,
        -5, 0, 0, 0, 0, 0, 0,-5,
        -5, 0, 0, 0, 0, 0, 0,-5,
        -5, 0, 0, 0, 0, 0, 0,-5,
         0, 0, 0, 5, 5, 0, 0, 0],
    q: [-20,-10,-10,-5,-5,-10,-10,-20,
        -10,  0,  0, 0, 0,  0,  0,-10,
        -10,  0,  5, 5, 5,  5,  0,-10,
         -5,  0,  5, 5, 5,  5,  0, -5,
          0,  0,  5, 5, 5,  5,  0, -5,
        -10,  5,  5, 5, 5,  5,  0,-10,
        -10,  0,  5, 0, 0,  0,  0,-10,
        -20,-10,-10,-5,-5,-10,-10,-20],
    k: [-30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -20,-30,-30,-40,-40,-30,-30,-20,
        -10,-20,-20,-20,-20,-20,-20,-10,
         20, 20,  0,  0,  0,  0, 20, 20,
         20, 30, 10,  0,  0, 10, 30, 20],
  };

  function evalBoard(b) {
    let score = 0;
    for (let r=0; r<8; r++) {
      for (let c=0; c<8; c++) {
        const p = b[r][c]; if (!p) continue;
        const pt  = p.toLowerCase();
        const val = PIECE_VALUES[pt] || 0;
        const pst = PST[pt];
        // White: read PST top-to-bottom (row 0=rank 8), Black: mirror
        const pstVal = pst ? (isWhite(p) ? pst[r*8+c] : pst[(7-r)*8+c]) : 0;
        score += isWhite(p) ? (val + pstVal) : -(val + pstVal);
      }
    }
    return score;
  }

  function aiMinimax(b, depth, alpha, beta, maximizing, ep, cas) {
    const side  = maximizing ? 'w' : 'b';
    const moves = getLegalMoves(b, side, ep, cas);
    if (depth === 0 || moves.length === 0) return { score: evalBoard(b) };

    // Shuffle moves to break ties randomly
    for (let i=moves.length-1; i>0; i--) {
      const j=Math.floor(Math.random()*(i+1));
      [moves[i],moves[j]]=[moves[j],moves[i]];
    }

    let best = maximizing ? -Infinity : Infinity;
    let bestMove = moves[0];

    for (const m of moves) {
      const { board:nb, castling:nc, enPassant:nep } = applyMove(b, m, cas, ep);
      const { score } = aiMinimax(nb, depth-1, alpha, beta, !maximizing, nep, nc);
      if (maximizing ? score > best : score < best) { best = score; bestMove = m; }
      if (maximizing) alpha = Math.max(alpha, best);
      else            beta  = Math.min(beta, best);
      if (beta <= alpha) break;
    }
    return { score: best, move: bestMove };
  }

  function scheduleAI() {
    if (aiTimer) clearTimeout(aiTimer);
    aiTimer = setTimeout(() => {
      // ── KEY FIX: only skip if game is truly over (checkmate/stalemate)
      // 'check' is a valid game state where the AI must still move
      if (turn !== 'b' || isGameOver()) return;

      thinking = true; render();

      // Use another timeout to allow the render to flush before heavy computation
      setTimeout(() => {
        const { move } = aiMinimax(board, 3, -Infinity, Infinity, false, enPassant, castling);
        thinking = false;
        if (move) {
          executeMove(move);
        } else {
          // No moves — shouldn't happen but safety net
          render();
        }
      }, 20);
    }, 250);
  }

  // ── Move execution ─────────────────────────────────────────────────────────
  function executeMove(move, promoteTo) {
    const { from:[fr,fc], to:[tr,tc] } = move;
    const p = board[fr][fc];
    const isPawnPromo = p.toLowerCase()==='p' && (tr===0||tr===7);

    const result = applyMove(board, move, castling, enPassant);
    board    = result.board;
    castling = result.castling;
    enPassant= result.enPassant;

    if (isPawnPromo) {
      const promo = promoteTo || (turn==='w' ? 'Q' : 'q');
      board[tr][tc] = promo;
    }

    moveHistory.push({ from:[fr,fc], to:[tr,tc] });
    turn = turn === 'w' ? 'b' : 'w';

    // Recompute status for the NEXT player
    const nextMoves = getLegalMoves(board, turn, enPassant, castling);
    if (nextMoves.length === 0) {
      status = inCheck(board, turn) ? 'checkmate' : 'stalemate';
    } else if (inCheck(board, turn)) {
      status = 'check';   // game continues — AI must still respond
    } else {
      status = '';
    }

    selected = null; legalMoves = [];
    saveState();
    render();

    // Schedule AI only if it's black's turn and game isn't over
    if (turn === 'b' && !isGameOver()) {
      scheduleAI();
    }
  }

  // ── Rendering ─────────────────────────────────────────────────────────────
  function render() {
    if (!container) return;
    const grid = container.querySelector('.ch-board');
    if (!grid) return;
    grid.innerHTML = '';

    const lastMove = moveHistory[moveHistory.length - 1];
    const inChk    = inCheck(board, turn);

    for (let r=0; r<8; r++) {
      for (let c=0; c<8; c++) {
        const sq = document.createElement('div');
        sq.className = 'ch-sq ' + ((r+c)%2===0 ? 'ch-light' : 'ch-dark');

        if (lastMove && (
          (lastMove.from[0]===r&&lastMove.from[1]===c) ||
          (lastMove.to[0]===r  &&lastMove.to[1]===c)
        )) sq.classList.add('ch-last');

        if (selected && selected[0]===r && selected[1]===c) sq.classList.add('ch-sel');

        const isLegal = legalMoves.some(m=>m.to[0]===r&&m.to[1]===c);
        if (isLegal) {
          sq.classList.add('ch-legal');
          if (board[r][c]) sq.classList.add('ch-capture');
        }

        // Highlight king square when in check
        if (inChk) {
          const kp = turn==='w' ? 'K' : 'k';
          if (board[r][c]===kp) sq.classList.add('ch-check');
        }

        if (board[r][c]) {
          const piece = document.createElement('span');
          piece.className = 'ch-piece ' + (isWhite(board[r][c]) ? 'ch-white' : 'ch-black');
          piece.textContent = PIECE_UNICODE[board[r][c]] || board[r][c];
          sq.appendChild(piece);
        }

        if (c===0) { const l=document.createElement('span'); l.className='ch-rank'; l.textContent=8-r; sq.appendChild(l); }
        if (r===7) { const l=document.createElement('span'); l.className='ch-file'; l.textContent='abcdefgh'[c]; sq.appendChild(l); }

        sq.addEventListener('click', () => onSquareClick(r, c));
        grid.appendChild(sq);
      }
    }

    const info = container.querySelector('.ch-info');
    if (info) {
      if (status==='checkmate')   info.textContent = `Checkmate! ${turn==='w'?'Black':'White'} wins`;
      else if (status==='stalemate') info.textContent = 'Stalemate — Draw';
      else if (thinking)          info.textContent = 'AI thinking...';
      else if (status==='check')  info.textContent = `${turn==='w'?'White':'Black'} is in Check`;
      else                        info.textContent = `${turn==='w'?'White (You)':'Black (AI)'} to move`;
    }

    const promoEl = container.querySelector('.ch-promo');
    if (promoEl) promoEl.style.display = promotionPending ? 'flex' : 'none';
  }

  function onSquareClick(r, c) {
    if (promotionPending || isGameOver() || thinking) return;
    if (turn === 'b') return;

    const p = board[r][c];

    if (selected) {
      const move = legalMoves.find(m=>m.to[0]===r&&m.to[1]===c);
      if (move) {
        const fromP = board[selected[0]][selected[1]];
        if (fromP.toLowerCase()==='p' && (r===0||r===7)) {
          promotionPending = move;
          render();
          return;
        }
        executeMove(move);
        return;
      }
    }

    if (color(p) === turn) {
      selected   = [r, c];
      legalMoves = getLegalMoves(board, turn, enPassant, castling)
                     .filter(m=>m.from[0]===r&&m.from[1]===c);
      render();
    } else {
      selected = null; legalMoves = []; render();
    }
  }

  // ── Public API ─────────────────────────────────────────────────────────────
  async function init(el) {
    container = el;
    container.innerHTML = `
      <div class="ch-info"></div>
      <div class="ch-board-wrap">
        <div class="ch-board"></div>
        <div class="ch-promo" style="display:none">
          <span class="ch-promo-label">Promote to:</span>
          <div class="ch-promo-btns">
            <button class="ch-promo-btn" data-piece="Q">♕ Queen</button>
            <button class="ch-promo-btn" data-piece="R">♖ Rook</button>
            <button class="ch-promo-btn" data-piece="B">♗ Bishop</button>
            <button class="ch-promo-btn" data-piece="N">♘ Knight</button>
          </div>
        </div>
      </div>
      <button class="btn-reset" id="btn-reset-ch">New Game</button>
      <div class="game-hint">Click piece to select &nbsp;|&nbsp; Click square to move &nbsp;|&nbsp; You play White</div>
    `;

    container.querySelectorAll('.ch-promo-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (!promotionPending) return;
        const piece = turn==='w' ? btn.dataset.piece : btn.dataset.piece.toLowerCase();
        const move  = promotionPending;
        promotionPending = null;
        executeMove(move, piece);
      });
    });

    container.querySelector('#btn-reset-ch').addEventListener('click', reset);

    const resumed = await loadState();
    if (!resumed) startNew();
    render();

    // If it's the AI's turn on load (e.g. game resumed mid-AI-turn), trigger it
    if (turn === 'b' && !isGameOver()) scheduleAI();
  }

  function startNew() {
    if (aiTimer) clearTimeout(aiTimer);
    parseFen(START_FEN);
    selected = null; legalMoves = []; status = '';
    moveHistory = []; promotionPending = null; thinking = false; aiTimer = null;
  }

  async function reset() {
    if (aiTimer) clearTimeout(aiTimer);
    await Storage.remove(STORAGE_KEY);
    startNew();
    render();
  }

  function onKey() {}

  return { init, onKey, reset };
})();
