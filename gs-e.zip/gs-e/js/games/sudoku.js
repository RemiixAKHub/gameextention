/* ═══════════════════════════════════════════════════════════════════════════
   SUDOKU  –  Pen / Pencil mode toggle
   Exports: GameSudoku  (consumed by popup.js)
═══════════════════════════════════════════════════════════════════════════ */
const GameSudoku = (() => {

  /* ── Puzzle bank ─────────────────────────────────────────────────────── */
  const PUZZLES = {
    easy: [
      ['530070000600195000098000060800060003400803001700020006060000280000419005000080079',
       '534678912672195348198342567859761423426853791713924856961537284287419635345286179'],
      ['200080300060070084030500209000105408000000000402706000301007040720040060004010003',
       '271986345963571284834524219619125478548397162472863591395712846127849653486213937'],
    ],
    medium: [
      ['000000907000420180000705026100904000050000040000507009920108000034059000507000000',
       '264831957795426183813795426127984365956213748438567219921148673634579812579362841'],
      ['030000000000195000008000060800060003400803001700020006060000280000410000000080079',
       '534678912672195348198342567859761423426853791713924856961537284287419635345286179'],
    ],
    hard: [
      ['800000000003600000070090200060005300004803001300010060020060005500009800000800700',
       '812753649943682175675491283168945327294837561357126498421968735589374912736215874'],
      ['000000085000210009960080100500800016000000000890006007009070052300054000480000000',
       '174396285538217469962485173593872416641539728827641957719768352356924781482153694'],
    ],
  };

  /* ── State ───────────────────────────────────────────────────────────── */
  let board, fixed, notes, solution;
  let sel = -1, pencilMode = false, diff = 'easy';
  let timer = 0, timerID = null, errors = 0;

  /* ── Helpers ─────────────────────────────────────────────────────────── */
  const $   = id => document.getElementById(id);
  const pad = n  => String(n).padStart(2,'0');
  const fmt = s  => `${pad(Math.floor(s/60))}:${pad(s%60)}`;

  function conflicts(idx) {
    const v = board[idx]; if (!v) return false;
    const r = Math.floor(idx/9), c = idx%9;
    const br = Math.floor(r/3)*3, bc = Math.floor(c/3)*3;
    for (let i=0;i<9;i++) {
      if (i!==c && board[r*9+i]===v) return true;
      if (i!==r && board[i*9+c]===v) return true;
    }
    for (let dr=0;dr<3;dr++) for (let dc=0;dc<3;dc++) {
      const ni=(br+dr)*9+(bc+dc);
      if (ni!==idx && board[ni]===v) return true;
    }
    return false;
  }

  function isSolved() { return board.every((v,i) => v===solution[i]); }

  /* ── Timer ───────────────────────────────────────────────────────────── */
  function startTimer() {
    clearInterval(timerID); timer = 0;
    timerID = setInterval(() => { timer++; renderTimer(); }, 1000);
  }
  function stopTimer()  { clearInterval(timerID); timerID = null; }
  function renderTimer(){ const el=$('sdk-timer'); if(el) el.textContent=fmt(timer); }

  /* ── New game ────────────────────────────────────────────────────────── */
  function newGame(d) {
    diff = d || diff;
    const bank = PUZZLES[diff];
    const [givens, sol] = bank[Math.floor(Math.random()*bank.length)];
    solution = sol.split('').map(Number);
    board    = givens.split('').map(Number);
    fixed    = board.map(v => v!==0);
    notes    = Array.from({length:81}, () => new Set());
    sel = -1; errors = 0; pencilMode = false;
    startTimer();
    render();
  }

  /* ── Input ───────────────────────────────────────────────────────────── */
  function placeValue(n) {
    if (sel<0 || fixed[sel]) return;
    if (pencilMode) {
      if (!n) { notes[sel].clear(); }
      else {
        if (board[sel]) return;
        notes[sel].has(n) ? notes[sel].delete(n) : notes[sel].add(n);
      }
    } else {
      if (board[sel]===n) { board[sel]=0; }
      else {
        board[sel]=n;
        notes[sel].clear();
        if (n) clearPeerNotes(sel,n);
        if (n && !conflicts(sel) && board[sel]!==solution[sel]) errors++;
      }
    }
    render();
    if (!pencilMode && isSolved()) onWin();
  }

  function clearPeerNotes(idx,v) {
    const r=Math.floor(idx/9),c=idx%9,br=Math.floor(r/3)*3,bc=Math.floor(c/3)*3;
    for (let i=0;i<9;i++) { notes[r*9+i].delete(v); notes[i*9+c].delete(v); }
    for (let dr=0;dr<3;dr++) for (let dc=0;dc<3;dc++) notes[(br+dr)*9+(bc+dc)].delete(v);
  }

  function onWin() {
    stopTimer();
    const info=$('sdk-info');
    if (info) info.textContent=`✓ Solved in ${fmt(timer)} — ${errors} error${errors!==1?'s':''}!`;
  }

  /* ── Mode toggle ─────────────────────────────────────────────────────── */
  function toggleMode() { pencilMode=!pencilMode; renderModeToggle(); }

  function renderModeToggle() {
    const btn=$('sdk-mode-btn'); if(!btn) return;
    if (pencilMode) {
      btn.textContent='✏ Pencil';
      btn.classList.add('sdk-mode-pencil'); btn.classList.remove('sdk-mode-pen');
    } else {
      btn.textContent='🖊 Pen';
      btn.classList.add('sdk-mode-pen'); btn.classList.remove('sdk-mode-pencil');
    }
  }

  /* ── Render ──────────────────────────────────────────────────────────── */
  function render() {
    const grid=$('sdk-grid'); if(!grid) return;
    const selRow=sel>=0?Math.floor(sel/9):-1;
    const selCol=sel>=0?sel%9:-1;
    const selBox=sel>=0?Math.floor(selRow/3)*3+Math.floor(selCol/3):-1;
    const selVal=sel>=0?board[sel]:0;

    grid.innerHTML='';
    for (let i=0;i<81;i++) {
      const r=Math.floor(i/9),c=i%9;
      const box=Math.floor(r/3)*3+Math.floor(c/3);
      const cell=document.createElement('div');
      cell.className='sdk-cell';
      if (c%3===0&&c!==0) cell.classList.add('sdk-box-left');
      if (r%3===0&&r!==0) cell.classList.add('sdk-box-top');
      if (i===sel)        { cell.classList.add('sdk-sel'); }
      else if (selRow>=0&&(r===selRow||c===selCol||box===selBox)) cell.classList.add('sdk-band');
      if (selVal&&board[i]===selVal&&!conflicts(i)) cell.classList.add('sdk-same-num');
      if (fixed[i])     cell.classList.add('sdk-fixed');
      if (conflicts(i)) cell.classList.add('sdk-conflict');

      if (notes[i].size>0&&!board[i]) {
        cell.classList.add('sdk-has-notes');
        const ng=document.createElement('div'); ng.className='sdk-notes';
        for (let n=1;n<=9;n++) {
          const s=document.createElement('span');
          s.textContent=notes[i].has(n)?n:'';
          ng.appendChild(s);
        }
        cell.appendChild(ng);
      } else {
        cell.textContent=board[i]||'';
      }

      cell.addEventListener('click',()=>{ sel=i; render(); });
      cell.addEventListener('contextmenu',e=>{
        e.preventDefault(); sel=i;
        if (!pencilMode) { pencilMode=true; renderModeToggle(); }
        render();
      });
      grid.appendChild(cell);
    }
    renderTimer(); renderModeToggle();
    const ec=$('sdk-err-count'); if(ec) ec.textContent=`Errors: ${errors}`;
  }

  /* ── Build pane ──────────────────────────────────────────────────────── */
  function buildPane(c) {
    c.innerHTML=`
      <div class="sdk-topbar">
        <div class="sdk-diff-bar">
          <button class="sdk-diff-btn active" data-d="easy">Easy</button>
          <button class="sdk-diff-btn" data-d="medium">Med</button>
          <button class="sdk-diff-btn" data-d="hard">Hard</button>
        </div>
        <span id="sdk-timer" class="sdk-timer">00:00</span>
        <span id="sdk-err-count" class="sdk-err-count">Errors: 0</span>
      </div>
      <div id="sdk-info" class="sdk-info"></div>
      <div id="sdk-grid" class="sdk-grid"></div>
      <div class="sdk-controls-row">
        <button id="sdk-mode-btn" class="sdk-mode-btn sdk-mode-pen" title="Toggle pen/pencil mode (P)">🖊 Pen</button>
        <div class="sdk-numpad">
          ${[1,2,3,4,5,6,7,8,9].map(n=>`<button class="sdk-num-btn" data-n="${n}">${n}</button>`).join('')}
          <button class="sdk-num-btn sdk-clr-btn" data-n="0">✕</button>
        </div>
      </div>
      <div class="game-hint">Click cell · 1-9 to fill · P toggles Pencil · Right-click → Pencil</div>
    `;
    c.querySelectorAll('.sdk-diff-btn').forEach(b=>{
      b.addEventListener('click',()=>{
        c.querySelectorAll('.sdk-diff-btn').forEach(x=>x.classList.remove('active'));
        b.classList.add('active'); newGame(b.dataset.d);
      });
    });
    $('sdk-mode-btn').addEventListener('click', toggleMode);
    c.querySelectorAll('.sdk-num-btn').forEach(b=>{
      b.addEventListener('click',()=>placeValue(+b.dataset.n));
    });
  }

  /* ── Public API — matches what popup.js expects ──────────────────────── */
  return {
    init(pane) { buildPane(pane); newGame('easy'); },
    onKey(e) {
      if (e.key==='p'||e.key==='P') { e.preventDefault(); toggleMode(); return; }
      if (e.key>='1'&&e.key<='9')   { e.preventDefault(); placeValue(+e.key); return; }
      if (e.key==='0'||e.key==='Delete'||e.key==='Backspace') { e.preventDefault(); placeValue(0); return; }
      if (sel>=0) {
        const mv={ArrowUp:-9,ArrowDown:9,ArrowLeft:-1,ArrowRight:1};
        if (mv[e.key]!==undefined) { e.preventDefault(); const ns=sel+mv[e.key]; if(ns>=0&&ns<81){sel=ns;render();} }
      }
    },
  };

})();
