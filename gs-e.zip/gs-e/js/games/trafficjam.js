/* ═══════════════════════════════════════════════════════════════════════════
   TRAFFIC JAM  –  115 levels, easy → challenging
   Exports: GameTrafficJam
   PATCH v2: drag movement · level validation + skip · localStorage save ·
             level-select screen · back-to-menu button
═══════════════════════════════════════════════════════════════════════════ */
const GameTrafficJam = (() => {

  const COLORS = [
    '#e53935','#1e88e5','#43a047','#fb8c00','#8e24aa',
    '#00acc1','#f4511e','#fdd835','#6d4c41','#546e7a',
    '#ec407a','#26a69a','#7cb342','#5e35b1','#039be5',
  ];

  const LEVELS = [
    // ── EASY (1-30) ──
    { cars:[[0,0,'h',2,2,2],[1,1,'v',1,0,2],[2,2,'v',4,5,2],[3,3,'h',4,3,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',0,3,2],[2,2,'h',0,0,2],[3,3,'h',4,0,3],[4,4,'v',3,5,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',0,2,3],[2,2,'v',1,5,2],[3,3,'h',3,1,2],[4,4,'v',4,0,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',0,0,3],[2,2,'h',1,1,2],[3,3,'h',3,3,2],[4,4,'v',4,5,2],[5,5,'h',5,0,3]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'h',1,2,2],[2,2,'v',3,2,2],[3,3,'h',0,3,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'v',0,1,2],[2,2,'h',0,2,2],[3,3,'v',3,4,3],[4,4,'h',5,0,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',1,2,3],[2,2,'v',0,5,3],[3,3,'h',3,0,2],[4,4,'h',4,3,2],[5,5,'v',4,0,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',0,0,2],[2,2,'h',0,1,3],[3,3,'v',2,4,2],[4,4,'h',4,0,3],[5,5,'v',3,5,3]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',0,0,3],[2,2,'v',1,3,2],[3,3,'h',1,4,2],[4,4,'v',3,1,2],[5,5,'h',5,2,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'v',0,4,3],[2,2,'h',0,0,2],[3,3,'v',1,0,2],[4,4,'h',3,1,3],[5,5,'v',4,5,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',0,2,2],[2,2,'h',1,3,2],[3,3,'v',2,5,2],[4,4,'h',4,1,2],[5,5,'v',3,0,3]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'h',0,0,3],[2,2,'v',1,5,2],[3,3,'h',3,0,2],[4,4,'v',4,3,2],[5,5,'h',5,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',0,3,3],[2,2,'h',0,0,2],[3,3,'h',1,4,2],[4,4,'v',3,0,2],[5,5,'h',4,1,3]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'h',5,0,2],[2,2,'h',3,1,2],[3,3,'v',1,1,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'v',0,0,2],[2,2,'v',4,4,2],[3,3,'h',4,1,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',0,0,3],[2,2,'h',0,1,2],[3,3,'v',0,3,2],[4,4,'h',3,2,2],[5,5,'v',4,4,2],[6,6,'h',5,0,3]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',1,2,2],[2,2,'v',0,4,2],[3,3,'v',2,5,2],[4,4,'h',3,1,3],[5,5,'v',4,0,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'v',0,1,2],[2,2,'h',0,2,3],[3,3,'v',1,5,2],[4,4,'h',3,0,2],[5,5,'v',4,3,2],[6,6,'h',5,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',0,1,3],[2,2,'v',0,4,2],[3,3,'h',1,0,2],[4,4,'v',3,5,2],[5,5,'h',4,1,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',0,3,2],[2,2,'h',0,4,2],[3,3,'v',1,0,2],[4,4,'h',3,0,3],[5,5,'v',4,5,2],[6,6,'h',5,2,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'v',2,0,2],[2,2,'h',4,1,2],[3,3,'v',3,3,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'h',0,0,2],[2,2,'v',0,2,2],[3,3,'v',1,4,2],[4,4,'h',3,1,2],[5,5,'v',3,0,2],[6,6,'h',5,3,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',0,2,2],[2,2,'v',0,4,3],[3,3,'h',1,0,2],[4,4,'v',3,2,2],[5,5,'h',4,3,2],[6,6,'v',4,5,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'h',5,0,2],[2,2,'v',0,5,2],[3,3,'v',4,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',0,3,2],[2,2,'h',0,4,2],[3,3,'h',1,0,2],[4,4,'v',2,5,2],[5,5,'h',3,1,3],[6,6,'v',4,0,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'h',0,0,3],[2,2,'v',0,3,2],[3,3,'v',1,5,2],[4,4,'h',3,0,2],[5,5,'v',3,2,2],[6,6,'h',5,3,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',0,2,2],[2,2,'h',0,3,2],[3,3,'v',0,5,3],[4,4,'h',1,0,2],[5,5,'v',3,1,3],[6,6,'h',4,3,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'h',0,0,2],[2,2,'v',0,2,2],[3,3,'h',1,3,2],[4,4,'v',1,5,2],[5,5,'h',3,0,3],[6,6,'v',4,4,2],[7,7,'h',5,1,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'h',3,1,3],[2,2,'h',0,2,2],[3,3,'h',3,4,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',4,4,2],[2,2,'h',3,0,2],[3,3,'v',0,1,2]] },
    // ── MEDIUM (31-70) ──
    { cars:[[0,0,'h',2,0,2],[1,1,'h',5,3,2],[2,2,'h',1,1,2],[3,3,'h',0,4,2],[4,4,'v',3,4,2],[5,5,'v',1,5,3],[6,6,'h',0,0,3],[7,7,'h',5,0,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',1,5,2],[2,2,'h',1,1,2],[3,3,'h',0,3,2],[4,4,'v',0,0,2],[5,5,'v',3,3,2],[6,6,'h',4,4,2],[7,7,'v',2,2,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',0,4,2],[2,2,'h',0,0,2],[3,3,'v',1,5,2],[4,4,'h',4,3,2],[5,5,'v',4,2,2],[6,6,'h',3,1,2],[7,7,'h',3,3,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',0,2,2],[2,2,'h',5,1,3],[3,3,'h',1,3,3],[4,4,'v',0,1,2],[5,5,'h',3,0,3],[6,6,'v',2,3,2],[7,7,'v',2,4,2],[8,8,'h',4,1,3]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',3,5,2],[2,2,'h',5,3,2],[3,3,'h',0,4,2],[4,4,'h',1,2,2],[5,5,'h',0,2,2],[6,6,'v',2,3,3],[7,7,'v',0,0,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',0,0,3],[2,2,'h',0,1,2],[3,3,'v',0,3,2],[4,4,'h',1,4,2],[5,5,'v',2,5,3],[6,6,'h',3,2,2],[7,7,'v',4,1,2],[8,8,'h',5,3,3]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',0,1,3],[2,2,'v',0,4,2],[3,3,'h',1,0,2],[4,4,'v',1,5,2],[5,5,'h',3,2,3],[6,6,'v',3,1,2],[7,7,'h',4,4,2],[8,8,'v',4,0,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',1,0,2],[2,2,'v',2,4,2],[3,3,'v',0,5,2],[4,4,'h',5,3,3],[5,5,'v',2,5,2],[6,6,'h',4,3,2],[7,7,'h',4,0,2],[8,8,'h',5,1,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',3,4,2],[2,2,'v',0,3,2],[3,3,'v',2,3,3],[4,4,'v',0,5,2],[5,5,'h',5,1,2],[6,6,'v',1,2,2],[7,7,'h',0,0,2],[8,8,'h',4,1,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',1,2,2],[2,2,'h',5,0,2],[3,3,'h',4,1,2],[4,4,'h',0,2,3],[5,5,'v',0,0,2],[6,6,'h',1,4,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',2,5,2],[2,2,'h',0,3,2],[3,3,'h',0,0,2],[4,4,'v',1,4,2],[5,5,'v',3,1,2],[6,6,'h',4,3,2],[7,7,'h',5,2,2],[8,8,'h',1,0,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'v',1,5,2],[2,2,'v',2,1,3],[3,3,'v',3,5,3],[4,4,'v',4,2,2],[5,5,'h',3,2,2],[6,6,'v',4,3,2],[7,7,'v',0,0,2],[8,8,'v',0,4,3]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',0,2,3],[2,2,'v',0,5,2],[3,3,'h',1,0,2],[4,4,'v',2,2,2],[5,5,'h',3,3,2],[6,6,'v',3,1,3],[7,7,'h',4,4,2],[8,8,'v',5,3,1]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',0,0,3],[2,2,'h',0,1,2],[3,3,'v',0,3,2],[4,4,'h',1,4,2],[5,5,'v',2,5,2],[6,6,'h',3,0,2],[7,7,'v',3,2,3],[8,8,'h',4,3,2],[9,9,'v',5,5,1]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',4,4,2],[2,2,'v',4,1,2],[3,3,'h',0,3,2],[4,4,'v',0,5,2],[5,5,'h',5,2,2],[6,6,'h',3,2,2],[7,7,'v',3,5,2],[8,8,'v',2,4,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'h',0,0,3],[2,2,'v',0,3,2],[3,3,'h',0,4,2],[4,4,'v',1,0,2],[5,5,'h',1,1,2],[6,6,'v',2,1,2],[7,7,'h',3,3,2],[8,8,'v',4,5,2],[9,9,'h',5,0,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'h',1,0,3],[2,2,'v',1,4,2],[3,3,'h',0,2,2],[4,4,'h',3,0,2],[5,5,'h',0,4,2],[6,6,'h',4,2,2],[7,7,'h',5,1,2],[8,8,'v',1,5,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',1,4,2],[2,2,'v',2,2,2],[3,3,'h',0,1,2],[4,4,'v',0,0,2],[5,5,'v',1,3,2],[6,6,'h',3,4,2],[7,7,'v',3,3,3]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'h',3,3,2],[2,2,'v',0,3,2],[3,3,'v',4,1,2],[4,4,'h',2,0,2],[5,5,'v',0,5,3],[6,6,'v',4,0,2],[7,7,'v',1,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',3,0,3],[2,2,'v',0,0,2],[3,3,'h',1,2,2],[4,4,'h',5,1,3],[5,5,'h',4,2,2],[6,6,'h',3,1,2],[7,7,'v',2,3,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',4,1,2],[2,2,'h',4,2,3],[3,3,'h',0,2,3],[4,4,'v',1,2,2],[5,5,'h',1,4,2],[6,6,'h',3,3,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',1,3,2],[2,2,'h',0,4,2],[3,3,'h',0,1,2],[4,4,'h',3,3,2],[5,5,'v',1,5,3],[6,6,'v',3,2,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'v',4,1,2],[2,2,'h',1,0,2],[3,3,'h',0,3,2],[4,4,'h',4,4,2],[5,5,'h',2,0,2],[6,6,'v',3,0,3],[7,7,'v',2,4,2],[8,8,'v',2,5,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'h',4,4,2],[2,2,'v',2,5,2],[3,3,'h',0,3,2],[4,4,'v',0,0,3],[5,5,'v',3,1,2],[6,6,'v',1,3,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',4,2,2],[2,2,'v',1,5,2],[3,3,'v',3,3,2],[4,4,'h',3,0,2],[5,5,'h',1,0,2],[6,6,'v',2,2,2],[7,7,'h',3,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',2,3,3],[2,2,'h',0,4,2],[3,3,'v',4,2,2],[4,4,'h',4,4,2],[5,5,'v',1,5,2],[6,6,'v',3,1,2],[7,7,'h',0,0,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'h',0,3,2],[2,2,'v',4,5,2],[3,3,'h',5,2,2],[4,4,'v',3,2,2],[5,5,'h',1,1,2],[6,6,'v',2,5,2],[7,7,'v',2,3,3],[8,8,'h',0,0,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',5,2,2],[2,2,'v',0,4,3],[3,3,'v',0,0,2],[4,4,'v',3,1,2],[5,5,'h',0,1,2],[6,6,'v',3,0,2],[7,7,'h',1,2,2],[8,8,'v',3,2,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',5,1,3],[2,2,'h',4,2,2],[3,3,'v',0,2,2],[4,4,'v',2,4,3],[5,5,'h',3,2,2],[6,6,'h',4,0,2],[7,7,'v',1,5,3]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'h',5,4,2],[2,2,'v',1,1,2],[3,3,'h',5,0,2],[4,4,'v',1,0,2],[5,5,'v',2,5,3],[6,6,'v',3,0,2],[7,7,'v',2,4,3],[8,8,'v',4,2,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',2,5,2],[2,2,'v',0,3,2],[3,3,'v',2,4,3],[4,4,'h',3,2,2],[5,5,'v',3,0,3],[6,6,'h',5,3,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',4,0,3],[2,2,'h',1,2,3],[3,3,'h',5,0,2],[4,4,'h',1,0,2],[5,5,'v',3,3,2],[6,6,'h',0,4,2],[7,7,'v',2,2,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'h',4,4,2],[2,2,'h',1,4,2],[3,3,'v',2,4,2],[4,4,'h',1,1,2],[5,5,'v',3,0,2],[6,6,'h',4,1,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',0,3,2],[2,2,'h',5,2,3],[3,3,'h',4,3,2],[4,4,'v',2,4,2],[5,5,'v',0,0,2],[6,6,'h',1,2,2],[7,7,'v',2,5,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',3,0,3],[2,2,'v',3,5,3],[3,3,'v',1,2,2],[4,4,'v',2,4,2],[5,5,'v',0,0,2],[6,6,'h',5,1,3],[7,7,'v',1,3,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',0,1,2],[2,2,'v',2,5,2],[3,3,'h',1,4,2],[4,4,'h',4,4,2],[5,5,'h',5,1,2],[6,6,'v',1,2,2],[7,7,'v',3,2,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',5,3,2],[2,2,'h',1,2,2],[3,3,'h',3,3,2],[4,4,'h',1,0,2],[5,5,'v',3,5,2],[6,6,'v',2,2,2],[7,7,'h',0,1,2],[8,8,'v',4,2,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',4,3,3],[2,2,'h',0,2,2],[3,3,'h',1,1,3],[4,4,'v',0,4,2],[5,5,'v',2,3,2],[6,6,'h',3,1,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'v',2,4,2],[2,2,'h',3,0,2],[3,3,'v',3,2,2],[4,4,'v',0,5,3],[5,5,'v',4,0,2],[6,6,'h',2,0,2],[7,7,'h',4,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',3,2,2],[2,2,'h',0,2,2],[3,3,'v',2,5,2],[4,4,'v',1,3,2],[5,5,'v',3,0,3],[6,6,'h',4,4,2],[7,7,'v',0,5,2],[8,8,'h',5,2,2]] },
    // ── HARD (71-100) ──
    { cars:[[0,0,'h',2,0,2],[1,1,'v',3,1,2],[2,2,'v',1,3,2],[3,3,'h',5,1,2],[4,4,'h',0,1,2],[5,5,'h',0,3,2],[6,6,'h',3,3,2],[7,7,'v',0,5,2],[8,8,'v',4,3,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',3,2,2],[2,2,'h',1,3,2],[3,3,'v',0,0,2],[4,4,'h',0,1,3],[5,5,'h',4,0,2],[6,6,'v',0,5,3],[7,7,'h',4,3,2],[8,8,'h',3,4,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'v',2,5,3],[2,2,'v',2,4,2],[3,3,'h',0,2,2],[4,4,'h',0,4,2],[5,5,'v',4,4,2],[6,6,'h',4,2,2],[7,7,'h',3,0,2],[8,8,'h',5,0,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',0,5,2],[2,2,'v',2,0,2],[3,3,'v',0,0,2],[4,4,'h',5,4,2],[5,5,'h',0,3,2],[6,6,'v',2,5,3],[7,7,'h',5,1,2],[8,8,'v',1,4,3]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',0,5,2],[2,2,'v',0,1,2],[3,3,'v',3,4,2],[4,4,'v',3,0,2],[5,5,'v',4,1,2],[6,6,'h',3,2,2],[7,7,'v',0,3,3],[8,8,'v',1,2,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',5,3,3],[2,2,'v',1,5,2],[3,3,'h',0,3,2],[4,4,'v',2,2,3],[5,5,'h',0,0,3],[6,6,'h',3,3,2],[7,7,'h',3,0,2],[8,8,'v',1,3,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',3,3,2],[2,2,'h',3,0,2],[3,3,'h',5,2,3],[4,4,'v',2,4,3],[5,5,'h',0,0,3],[6,6,'v',1,2,2],[7,7,'v',1,3,2],[8,8,'v',0,5,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',1,4,2],[2,2,'v',4,2,2],[3,3,'v',2,3,2],[4,4,'h',0,2,2],[5,5,'v',4,3,2],[6,6,'v',0,5,2],[7,7,'v',4,4,2],[8,8,'v',2,5,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'h',5,2,2],[2,2,'v',0,3,3],[3,3,'h',4,0,2],[4,4,'v',2,5,2],[5,5,'h',5,4,2],[6,6,'h',3,2,2],[7,7,'v',0,4,2],[8,8,'h',4,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',3,5,2],[2,2,'v',3,3,3],[3,3,'h',0,3,2],[4,4,'v',1,3,2],[5,5,'h',5,1,2],[6,6,'h',0,0,2],[7,7,'v',2,2,3],[8,8,'v',1,4,3]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',1,4,3],[2,2,'h',0,3,3],[3,3,'h',1,0,2],[4,4,'v',1,3,2],[5,5,'v',3,5,2],[6,6,'h',3,1,3],[7,7,'h',0,0,3],[8,8,'h',4,1,3]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',0,1,3],[2,2,'h',1,4,2],[3,3,'h',4,3,2],[4,4,'v',1,2,3],[5,5,'v',3,1,2],[6,6,'h',5,3,2],[7,7,'v',2,4,2],[8,8,'v',4,0,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',3,3,2],[2,2,'v',0,0,2],[3,3,'h',1,4,2],[4,4,'h',0,3,3],[5,5,'v',2,5,2],[6,6,'h',3,0,2],[7,7,'v',1,3,2],[8,8,'h',5,1,3]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'v',0,4,3],[2,2,'v',3,1,2],[3,3,'h',4,2,3],[4,4,'h',1,1,3],[5,5,'h',5,4,2],[6,6,'h',3,3,2],[7,7,'h',0,1,2],[8,8,'v',3,5,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',0,1,2],[2,2,'v',1,3,2],[3,3,'h',4,3,3],[4,4,'v',2,2,2],[5,5,'v',3,1,2],[6,6,'v',0,0,2],[7,7,'v',1,5,3],[8,8,'v',3,0,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',3,5,2],[2,2,'v',3,2,2],[3,3,'v',1,4,2],[4,4,'v',4,1,2],[5,5,'v',3,0,3],[6,6,'h',0,2,2],[7,7,'v',1,3,3],[8,8,'h',4,3,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',2,2,2],[2,2,'v',2,3,2],[3,3,'v',1,4,3],[4,4,'v',1,5,2],[5,5,'h',1,2,2],[6,6,'h',1,0,2],[7,7,'h',0,2,3],[8,8,'h',5,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',1,3,3],[2,2,'h',3,4,2],[3,3,'h',5,1,2],[4,4,'v',1,2,2],[5,5,'h',4,2,3],[6,6,'h',5,4,2],[7,7,'v',1,5,2],[8,8,'h',0,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',0,1,3],[2,2,'h',5,2,2],[3,3,'h',4,0,2],[4,4,'h',3,3,2],[5,5,'v',0,4,3],[6,6,'v',3,2,2],[7,7,'v',0,0,2],[8,8,'v',0,5,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'h',5,2,2],[2,2,'v',2,4,2],[3,3,'v',1,3,3],[4,4,'v',2,5,2],[5,5,'v',3,0,2],[6,6,'h',4,2,3],[7,7,'h',3,1,2],[8,8,'h',0,1,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',4,0,2],[2,2,'h',5,2,2],[3,3,'h',0,4,2],[4,4,'h',3,2,2],[5,5,'v',0,2,2],[6,6,'h',4,3,3],[7,7,'v',1,4,2],[8,8,'h',3,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',1,0,2],[2,2,'h',0,4,2],[3,3,'v',1,5,3],[4,4,'h',0,1,2],[5,5,'h',1,2,2],[6,6,'v',2,2,3],[7,7,'h',5,1,3],[8,8,'v',4,0,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'v',4,5,2],[2,2,'v',1,0,2],[3,3,'v',4,2,2],[4,4,'h',0,4,2],[5,5,'h',0,0,3],[6,6,'v',1,4,2],[7,7,'v',2,5,2],[8,8,'v',0,3,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',0,5,3],[2,2,'v',0,3,2],[3,3,'v',3,1,2],[4,4,'h',4,4,2],[5,5,'h',3,2,2],[6,6,'h',3,4,2],[7,7,'h',0,1,2],[8,8,'h',5,1,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',1,3,3],[2,2,'h',4,3,2],[3,3,'h',3,0,2],[4,4,'h',5,1,2],[5,5,'h',4,1,2],[6,6,'v',1,2,2],[7,7,'v',4,5,2],[8,8,'h',1,0,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',4,3,2],[2,2,'h',4,4,2],[3,3,'v',1,4,2],[4,4,'h',0,0,2],[5,5,'h',3,2,2],[6,6,'h',0,3,3],[7,7,'h',1,2,2],[8,8,'v',3,0,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',1,2,2],[2,2,'h',0,2,3],[3,3,'v',2,3,2],[4,4,'v',4,4,2],[5,5,'h',5,1,2],[6,6,'v',2,4,2],[7,7,'h',4,2,2],[8,8,'v',0,5,3]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'h',1,1,3],[2,2,'h',4,2,2],[3,3,'v',3,1,2],[4,4,'h',0,3,2],[5,5,'v',1,5,3],[6,6,'v',0,0,2],[7,7,'v',2,3,2],[8,8,'v',2,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',1,3,2],[2,2,'h',4,3,2],[3,3,'h',4,0,3],[4,4,'v',2,3,2],[5,5,'v',1,5,2],[6,6,'h',1,1,2],[7,7,'h',0,4,2],[8,8,'v',2,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',1,5,2],[2,2,'h',1,0,2],[3,3,'h',0,4,2],[4,4,'v',0,3,3],[5,5,'h',3,3,2],[6,6,'h',5,3,3],[7,7,'v',3,0,2],[8,8,'h',0,0,2]] },
    // ── EXPERT (101-115) ──
    { cars:[[0,0,'h',2,0,2],[1,1,'v',2,3,3],[2,2,'v',1,5,2],[3,3,'v',3,0,3],[4,4,'h',1,2,3],[5,5,'v',2,4,2],[6,6,'h',0,3,2],[7,7,'v',4,1,2],[8,8,'h',5,2,3],[9,9,'v',0,0,2],[10,10,'v',2,2,2],[11,11,'v',4,5,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',1,5,3],[2,2,'h',0,2,2],[3,3,'v',0,1,2],[4,4,'v',2,3,2],[5,5,'h',5,0,2],[6,6,'v',4,4,2],[7,7,'h',5,2,2],[8,8,'v',1,2,3],[9,9,'v',1,4,2],[10,10,'h',3,0,2],[11,11,'v',0,0,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',2,3,2],[2,2,'h',4,3,3],[3,3,'h',3,1,2],[4,4,'v',0,0,2],[5,5,'v',4,0,2],[6,6,'h',0,3,2],[7,7,'h',1,4,2],[8,8,'h',1,1,3],[9,9,'v',2,5,2],[10,10,'h',5,4,2],[11,11,'v',4,1,2]] },
    { cars:[[0,0,'h',2,2,2],[1,1,'v',1,4,2],[2,2,'h',0,0,2],[3,3,'v',4,2,2],[4,4,'v',2,1,2],[5,5,'v',4,4,2],[6,6,'h',0,4,2],[7,7,'h',3,3,2],[8,8,'v',0,3,2],[9,9,'v',3,5,2],[10,10,'h',1,1,2],[11,11,'v',4,0,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'h',1,2,2],[2,2,'h',3,1,2],[3,3,'v',3,3,2],[4,4,'h',5,4,2],[5,5,'v',0,4,3],[6,6,'v',1,0,2],[7,7,'h',5,2,2],[8,8,'v',2,5,3],[9,9,'v',3,0,3],[10,10,'h',4,1,2],[11,11,'v',0,1,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',0,3,3],[2,2,'v',1,2,2],[3,3,'h',3,1,3],[4,4,'v',2,5,2],[5,5,'h',5,4,2],[6,6,'h',4,1,2],[7,7,'h',0,0,3],[8,8,'h',1,0,2],[9,9,'h',1,4,2],[10,10,'h',4,3,2],[11,11,'h',5,1,3]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',4,1,2],[2,2,'v',1,5,2],[3,3,'h',5,3,2],[4,4,'h',1,2,2],[5,5,'v',2,3,2],[6,6,'v',3,0,2],[7,7,'v',4,5,2],[8,8,'v',2,4,2],[9,9,'h',0,4,2],[10,10,'h',4,3,2],[11,11,'v',0,0,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'h',3,3,2],[2,2,'h',5,0,2],[3,3,'v',1,3,2],[4,4,'v',4,5,2],[5,5,'v',1,4,2],[6,6,'v',4,4,2],[7,7,'v',2,5,2],[8,8,'h',3,0,2],[9,9,'h',4,2,2],[10,10,'h',0,4,2],[11,11,'h',0,1,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',3,3,2],[2,2,'h',3,0,2],[3,3,'v',0,5,2],[4,4,'h',5,1,2],[5,5,'v',2,5,2],[6,6,'v',4,4,2],[7,7,'h',1,3,2],[8,8,'v',1,2,3],[9,9,'h',0,0,2],[10,10,'v',2,4,2],[11,11,'v',4,0,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',1,2,3],[2,2,'h',4,1,2],[3,3,'h',4,4,2],[4,4,'v',0,0,2],[5,5,'v',1,5,2],[6,6,'h',0,1,2],[7,7,'h',5,3,2],[8,8,'h',0,3,2],[9,9,'h',3,0,3],[10,10,'v',2,3,3],[11,11,'v',2,4,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'v',3,2,3],[2,2,'h',1,2,2],[3,3,'h',0,3,2],[4,4,'v',2,4,3],[5,5,'v',0,5,2],[6,6,'v',4,0,2],[7,7,'v',0,1,2],[8,8,'v',3,1,2],[9,9,'v',2,5,2],[10,10,'v',2,3,2],[11,11,'h',5,3,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'v',3,2,2],[2,2,'h',4,3,3],[3,3,'h',5,0,2],[4,4,'v',1,3,2],[5,5,'v',0,4,2],[6,6,'v',2,4,2],[7,7,'h',5,4,2],[8,8,'v',2,0,2],[9,9,'v',2,5,2],[10,10,'v',0,1,2],[11,11,'v',0,5,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',1,4,2],[2,2,'v',2,4,2],[3,3,'h',5,4,2],[4,4,'v',0,1,2],[5,5,'h',4,0,2],[6,6,'v',2,2,2],[7,7,'h',4,3,2],[8,8,'v',2,5,2],[9,9,'h',0,2,2],[10,10,'h',1,2,2],[11,11,'h',5,1,2]] },
    { cars:[[0,0,'h',2,0,2],[1,1,'h',5,4,2],[2,2,'v',1,5,2],[3,3,'h',4,0,2],[4,4,'v',0,2,2],[5,5,'v',0,1,2],[6,6,'v',0,4,3],[7,7,'h',5,2,2],[8,8,'h',3,2,2],[9,9,'v',0,0,2],[10,10,'h',4,4,2],[11,11,'v',0,3,2]] },
    { cars:[[0,0,'h',2,1,2],[1,1,'h',4,2,2],[2,2,'v',2,4,2],[3,3,'h',0,4,2],[4,4,'v',3,1,3],[5,5,'h',5,4,2],[6,6,'v',0,3,3],[7,7,'h',0,1,2],[8,8,'v',4,0,2],[9,9,'h',3,2,2],[10,10,'v',1,0,2],[11,11,'h',1,1,2]] },
  ];

  const DIFF_LABELS = [
    'Easy','Easy','Easy','Easy','Easy','Easy','Easy','Easy','Easy','Easy',
    'Easy','Easy','Easy','Easy','Easy','Easy','Easy','Easy','Easy','Easy',
    'Easy','Easy','Easy','Easy','Easy','Easy','Easy','Easy','Easy','Easy',
    'Med','Med','Med','Med','Med','Med','Med','Med','Med','Med',
    'Med','Med','Med','Med','Med','Med','Med','Med','Med','Med',
    'Med','Med','Med','Med','Med','Med','Med','Med','Med','Med',
    'Med','Med','Med','Med','Med','Med','Med','Med','Med','Med',
    'Hard','Hard','Hard','Hard','Hard','Hard','Hard','Hard','Hard','Hard',
    'Hard','Hard','Hard','Hard','Hard','Hard','Hard','Hard','Hard','Hard',
    'Hard','Hard','Hard','Hard','Hard','Hard','Hard','Hard','Hard','Hard',
    'Expert','Expert','Expert','Expert','Expert','Expert','Expert','Expert','Expert','Expert',
    'Expert','Expert','Expert','Expert','Expert',
  ];

  const CELL = 54;
  const SAVE_KEY = 'tj_save_v1';

  /* ── State ───────────────────────────────────────────────────────────── */
  let levelIdx    = 0;
  let cars        = [];
  let selected    = -1;
  let moveCount   = 0;
  let bestScores  = {};
  let unlockedUpTo = 0;
  let container   = null;
  let won         = false;
  let screen      = 'select'; // 'select' | 'game'

  /* ── Drag state ──────────────────────────────────────────────────────── */
  let drag = null;
  // drag = { carIdx, orient, startX, startY, startCol, startRow, moved }

  /* ══════════════════════════════════════════════════════════════════════
     SAVE / LOAD  (localStorage)
  ══════════════════════════════════════════════════════════════════════ */
  function saveProgress() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify({
        currentLevel: levelIdx,
        unlockedUpTo,
        bestScores,
      }));
    } catch(e) { /* storage full – silently ignore */ }
  }

  function loadProgress() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const data = JSON.parse(raw);
      if (typeof data.currentLevel  === 'number') levelIdx     = data.currentLevel;
      if (typeof data.unlockedUpTo  === 'number') unlockedUpTo = data.unlockedUpTo;
      if (data.bestScores && typeof data.bestScores === 'object') bestScores = data.bestScores;
    } catch(e) { /* corrupt save – start fresh */ }
  }

  /* ══════════════════════════════════════════════════════════════════════
     VALIDATION
  ══════════════════════════════════════════════════════════════════════ */
  function isValidLevel(idx) {
    if (idx < 0 || idx >= LEVELS.length) return false;
    const def = LEVELS[idx];
    // Must have a red car (id 0) on row 2, horizontal
    const redDef = def.cars.find(c => c[0] === 0);
    if (!redDef || redDef[2] !== 'h' || redDef[3] !== 2) return false;
    // Check for overlapping cells
    const seen = new Set();
    for (const [,, orient, row, col, len] of def.cars) {
      for (let s = 0; s < len; s++) {
        const r = orient === 'h' ? row     : row + s;
        const c = orient === 'h' ? col + s : col;
        if (r < 0 || r > 5 || c < 0 || c > 5) return false; // out of bounds
        const key = r * 6 + c;
        if (seen.has(key)) return false; // overlap
        seen.add(key);
      }
    }
    return true;
  }

  /* Find the next valid level at or after `start`. Returns -1 if none. */
  function findNextValid(start) {
    let level = start;
    while (level < LEVELS.length && !isValidLevel(level)) {
      console.warn(`[TrafficJam] Level ${level + 1} is invalid – skipping.`);
      level++;
    }
    return level < LEVELS.length ? level : -1;
  }

  /* ══════════════════════════════════════════════════════════════════════
     LEVEL LOADING
  ══════════════════════════════════════════════════════════════════════ */
  function loadLevel(idx) {
    const validIdx = findNextValid(idx);
    if (validIdx === -1) {
      showError('No valid levels found from level ' + (idx + 1) + '. Cannot continue.');
      return;
    }
    levelIdx  = validIdx;
    const def = LEVELS[validIdx];
    cars      = def.cars.map(([id, ci, o, r, c, l]) => ({ id, colorIdx: ci, orient: o, row: r, col: c, len: l }));
    selected  = -1;
    moveCount = 0;
    won       = false;
    drag      = null;
    screen    = 'game';
    saveProgress();
    renderGame();
  }

  function showError(msg) {
    if (!container) return;
    container.innerHTML = `<div class="tj-error">${msg}</div>`;
  }

  /* ══════════════════════════════════════════════════════════════════════
     GRID / MOVEMENT  (unchanged logic, same function signatures)
  ══════════════════════════════════════════════════════════════════════ */
  function buildGrid() {
    const g = Array.from({ length: 6 }, () => Array(6).fill(-1));
    cars.forEach((car, i) => {
      for (let s = 0; s < car.len; s++) {
        const r = car.orient === 'h' ? car.row       : car.row + s;
        const c = car.orient === 'h' ? car.col + s   : car.col;
        if (r >= 0 && r < 6 && c >= 0 && c < 6) g[r][c] = i;
      }
    });
    return g;
  }

  function canMove(carIdx, dir) {
    const car = cars[carIdx];
    const g   = buildGrid();
    if (car.orient === 'h') {
      if (dir === 'left')  { const nc = car.col - 1;          if (nc < 0)  return false; return g[car.row][nc] === -1; }
      if (dir === 'right') { const nc = car.col + car.len;    if (nc > 5)  return car.id === 0; return g[car.row][nc] === -1; }
    } else {
      if (dir === 'up')    { const nr = car.row - 1;          if (nr < 0)  return false; return g[nr][car.col] === -1; }
      if (dir === 'down')  { const nr = car.row + car.len;    if (nr > 5)  return false; return g[nr][car.col] === -1; }
    }
    return false;
  }

  /* Move one tile in dir. Returns true if actually moved. */
  function moveCar(carIdx, dir) {
    const car = cars[carIdx];
    let moved = false;
    if (car.orient === 'h') {
      if (dir === 'left'  && canMove(carIdx, 'left'))  { car.col--; moveCount++; moved = true; }
      if (dir === 'right' && canMove(carIdx, 'right')) {
        car.col++; moveCount++; moved = true;
        if (car.id === 0 && car.col + car.len > 6) { onWin(); return true; }
      }
    } else {
      if (dir === 'up'   && canMove(carIdx, 'up'))   { car.row--; moveCount++; moved = true; }
      if (dir === 'down' && canMove(carIdx, 'down')) { car.row++; moveCount++; moved = true; }
    }
    return moved;
  }

  function checkWin() {
    const red = cars.find(c => c.id === 0);
    if (red && red.orient === 'h' && red.row === 2 && red.col + red.len >= 6) onWin();
  }

  function onWin() {
    if (won) return;
    won = true;
    if (!bestScores[levelIdx] || moveCount < bestScores[levelIdx]) bestScores[levelIdx] = moveCount;
    const next = findNextValid(levelIdx + 1);
    if (next !== -1 && next > unlockedUpTo) unlockedUpTo = next;
    saveProgress();
    renderGame();
  }

  /* ══════════════════════════════════════════════════════════════════════
     DRAG HANDLERS
  ══════════════════════════════════════════════════════════════════════ */
  function onCarPointerDown(e, carIdx) {
    if (won) return;
    e.preventDefault();
    selected = carIdx;
    const car  = cars[carIdx];
    drag = {
      carIdx,
      orient:   car.orient,
      startX:   e.clientX,
      startY:   e.clientY,
      startCol: car.col,
      startRow: car.row,
      lastCol:  car.col,
      lastRow:  car.row,
    };
    // Capture the pointer so pointermove/pointerup keep firing even if
    // the pointer leaves the car element during a fast drag.
    try { e.target.setPointerCapture(e.pointerId); } catch(_) {}
    renderGame();
  }

  function onGridPointerMove(e) {
    if (!drag || won) return;
    e.preventDefault();
    const car     = cars[drag.carIdx];
    const dx      = e.clientX - drag.startX;
    const dy      = e.clientY - drag.startY;

    if (drag.orient === 'h') {
      const targetCol = drag.startCol + Math.round(dx / CELL);
      const clampedCol = Math.max(0, Math.min(6 - car.len, targetCol));
      // Move step by step toward target
      while (car.col !== clampedCol) {
        const dir = car.col < clampedCol ? 'right' : 'left';
        if (!moveCar(drag.carIdx, dir)) break;
      }
    } else {
      const targetRow = drag.startRow + Math.round(dy / CELL);
      const clampedRow = Math.max(0, Math.min(6 - car.len, targetRow));
      while (car.row !== clampedRow) {
        const dir = car.row < clampedRow ? 'down' : 'up';
        if (!moveCar(drag.carIdx, dir)) break;
      }
    }
    checkWin();
    renderGame();
  }

  function onGridPointerUp(e) {
    if (!drag) return;
    drag = null;
    renderGame();
  }

  /* ══════════════════════════════════════════════════════════════════════
     LEVEL SELECT SCREEN
  ══════════════════════════════════════════════════════════════════════ */
  function renderLevelSelect() {
    if (!container) return;
    const wrap = container.querySelector('.tj-select-wrap');
    if (!wrap) return;

    wrap.innerHTML = '';
    LEVELS.forEach((_, i) => {
      const btn    = document.createElement('button');
      const locked = i > unlockedUpTo;
      const done   = bestScores[i] !== undefined;
      btn.className = 'tj-sel-btn' +
        (locked ? ' tj-sel-locked' : '') +
        (done   ? ' tj-sel-done'   : '');
      btn.textContent = i + 1;
      btn.title = locked
        ? 'Locked'
        : `${DIFF_LABELS[i]}${done ? ' · Best ' + bestScores[i] : ''}`;
      btn.disabled = locked;
      if (!locked) btn.addEventListener('click', () => loadLevel(i));
      wrap.appendChild(btn);
    });
  }

  function showLevelSelect() {
    screen   = 'select';
    selected = -1;
    drag     = null;
    if (!container) return;
    container.innerHTML = `
      <div class="tj-select-header">
        <span class="tj-select-title">Traffic Jam — Select Level</span>
      </div>
      <div class="tj-select-wrap"></div>
      <div class="tj-select-legend">
        <span class="tj-leg tj-leg-open">■</span> Open &nbsp;
        <span class="tj-leg tj-leg-done">■</span> Solved &nbsp;
        <span class="tj-leg tj-leg-locked">■</span> Locked
      </div>
    `;
    renderLevelSelect();
  }

  /* ══════════════════════════════════════════════════════════════════════
     GAME RENDER
  ══════════════════════════════════════════════════════════════════════ */
  function renderGame() {
    if (!container) return;

    // If we're not already showing the game board, rebuild it
    if (!container.querySelector('.tj-board-wrap')) {
      container.innerHTML = `
        <div class="tj-topbar">
          <button class="tj-btn tj-btn-sm" id="tj-menu-btn">☰ Levels</button>
          <span class="tj-status"></span>
          <button class="tj-btn tj-btn-sm" id="tj-restart">↺ Reset</button>
        </div>
        <div class="tj-board-wrap">
          <div class="tj-grid"></div>
        </div>
        <div class="game-hint">Drag a car to move it · get the red car to ▶ exit</div>
      `;
      container.querySelector('#tj-restart').addEventListener('click', () => loadLevel(levelIdx));
      container.querySelector('#tj-menu-btn').addEventListener('click', () => showLevelSelect());

      // Pointer events on the grid for drag
      const grid = container.querySelector('.tj-grid');
      grid.addEventListener('pointermove',  onGridPointerMove, { passive: false });
      grid.addEventListener('pointerup',    onGridPointerUp);
      grid.addEventListener('pointercancel',onGridPointerUp);
    }

    const grid = container.querySelector('.tj-grid');
    grid.innerHTML = '';

    // Exit arrow
    const arrow = document.createElement('div');
    arrow.className   = 'tj-exit-arrow';
    arrow.textContent = '▶';
    grid.appendChild(arrow);

    // Cars
    cars.forEach((car, i) => {
      const el  = document.createElement('div');
      const isH = car.orient === 'h';
      const w   = isH ? car.len * CELL - 4 : CELL - 4;
      const h   = isH ? CELL - 4           : car.len * CELL - 4;
      el.className = 'tj-car' +
        (i === selected ? ' tj-selected' : '') +
        (car.id === 0   ? ' tj-red-car'  : '');
      el.style.cssText = `
        left:${car.col * CELL + 2}px; top:${car.row * CELL + 2}px;
        width:${w}px; height:${h}px;
        background:${COLORS[car.colorIdx]};
        transition: left 0.06s, top 0.06s;
      `;
      const hint       = document.createElement('span');
      hint.className   = 'tj-car-hint';
      hint.textContent = isH ? '◀▶' : '▲▼';
      el.appendChild(hint);
      // Pointer down starts drag
      el.addEventListener('pointerdown', e => onCarPointerDown(e, i));
      grid.appendChild(el);
    });

    // Win overlay
    const oldWin = container.querySelector('.tj-win');
    if (oldWin) oldWin.remove();
    if (won) {
      const isLast = findNextValid(levelIdx + 1) === -1;
      const w      = document.createElement('div');
      w.className  = 'tj-win';
      w.innerHTML  = `
        <div class="tj-win-box">
          <div class="tj-win-title">🎉 Solved!</div>
          <div class="tj-win-moves">${moveCount} move${moveCount !== 1 ? 's' : ''}</div>
          ${bestScores[levelIdx] ? `<div class="tj-win-best">Best: ${bestScores[levelIdx]}</div>` : ''}
          ${!isLast ? `<button class="tj-btn" id="tj-next-btn">Next Level ▶</button>` : '<div style="color:var(--yellow)">All 115 levels complete! 🏆</div>'}
          <button class="tj-btn tj-btn-ghost" id="tj-menu2-btn">☰ Level Select</button>
          <button class="tj-btn tj-btn-ghost" id="tj-replay-btn">↺ Replay</button>
        </div>
      `;
      container.querySelector('.tj-board-wrap').appendChild(w);
      w.querySelector('#tj-next-btn')?.addEventListener('click',  () => loadLevel(levelIdx + 1));
      w.querySelector('#tj-replay-btn')?.addEventListener('click', () => loadLevel(levelIdx));
      w.querySelector('#tj-menu2-btn')?.addEventListener('click',  () => showLevelSelect());
    }

    // Status bar
    const status = container.querySelector('.tj-status');
    if (status) {
      const diff = DIFF_LABELS[levelIdx] || '';
      const best = bestScores[levelIdx] !== undefined ? ` · Best ${bestScores[levelIdx]}` : '';
      status.textContent = `Lvl ${levelIdx + 1}/115 · ${diff} · Moves: ${moveCount}${best}`;
    }
  }

  /* ══════════════════════════════════════════════════════════════════════
     INIT / PUBLIC API
  ══════════════════════════════════════════════════════════════════════ */
  function init(pane) {
    container = pane;
    loadProgress();
    // Validate saved level index
    if (levelIdx < 0 || levelIdx >= LEVELS.length) levelIdx = 0;
    showLevelSelect();
  }

  function onKey(e) {
    if (screen !== 'game' || won) return;
    if (selected < 0) return;
    const car = cars[selected];
    const map = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' };
    const dir = map[e.key];
    if (!dir) return;
    if (car.orient === 'h' && (dir === 'left' || dir === 'right')) {
      e.preventDefault(); moveCar(selected, dir); checkWin(); renderGame();
    }
    if (car.orient === 'v' && (dir === 'up' || dir === 'down')) {
      e.preventDefault(); moveCar(selected, dir); checkWin(); renderGame();
    }
  }

  return { init, onKey };

})();
