// solitaire.js — Klondike Solitaire — fully rewritten, clean render
const GameSolitaire = (() => {
  const STORAGE_KEY = 'game_solitaire';
  const SUITS = ['♠','♥','♦','♣'];
  const RANKS = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];

  let stock=[], waste=[], foundations=[[],[],[],[]], tableau=[[],[],[],[],[],[],[]];
  let selected=null; // {source:'waste'|'tableau', col, cardIdx}
  let moves=0, won=false, container=null;
  let history=null; // HistoryManager instance — created in init()

  function serialize() { return {stock,waste,foundations,tableau,moves,won}; }

  // ── Undo/Redo (command/snapshot pattern) ────────────────────────────────
  // A snapshot captures every field that defines the game's visible state.
  // Because the full state is tiny (52 cards), snapshotting before each
  // discrete player action is cheap and removes the need for per-move-type
  // "reverse" logic (which is where undo bugs usually hide — e.g. forgetting
  // to re-hide a flipped card, or mis-restoring stock/waste on a recycle).
  function snapshotState() {
    return JSON.parse(JSON.stringify({stock,waste,foundations,tableau,moves,won}));
  }
  function restoreState(snap) {
    stock=snap.stock; waste=snap.waste; foundations=snap.foundations;
    tableau=snap.tableau; moves=snap.moves; won=snap.won;
    selected=null;
  }
  // Wrap a mutating action: snapshot before, run it, then push to history
  // ONLY if the state actually changed (keeps no-op clicks, e.g. an Auto
  // press that finds nothing to do, out of the undo stack).
  function commitMove(label, mutateFn) {
    const before=snapshotState();
    mutateFn();
    const after=snapshotState();
    if (JSON.stringify(before)!==JSON.stringify(after)) history.push(before,label);
  }
  function doUndo() {
    if (!history||!history.canUndo()) return;
    const current=snapshotState();
    const prev=history.undo(current);
    if (prev) { restoreState(prev); saveState(); render(); }
  }
  function doRedo() {
    if (!history||!history.canRedo()) return;
    const current=snapshotState();
    const next=history.redo(current);
    if (next) { restoreState(next); saveState(); render(); }
  }
  async function saveState() { Storage.saveLazy(STORAGE_KEY,serialize()); }
  async function loadState() {
    const s=await Storage.load(STORAGE_KEY);
    if (s&&s.tableau&&s.tableau.length===7) {
      stock=s.stock; waste=s.waste; foundations=s.foundations;
      tableau=s.tableau; moves=s.moves; won=s.won; return true;
    }
    return false;
  }

  function isRed(card) { return card.s==='♥'||card.s==='♦'; }
  function rankIdx(r)  { return RANKS.indexOf(r); }

  function canFoundation(card,pile) {
    if (!pile.length) return card.r==='A';
    const top=pile[pile.length-1];
    return card.s===top.s && rankIdx(card.r)===rankIdx(top.r)+1;
  }
  function canTableau(card,col) {
    const pile=tableau[col];
    if (!pile.length) return card.r==='K';
    const top=pile[pile.length-1];
    return top.up && isRed(card)!==isRed(top) && rankIdx(card.r)===rankIdx(top.r)-1;
  }

  function startNew() {
    const deck=[];
    for (const s of SUITS) for (const r of RANKS) deck.push({r,s,up:false});
    for (let i=deck.length-1;i>0;i--) {
      const j=Math.floor(Math.random()*(i+1));
      [deck[i],deck[j]]=[deck[j],deck[i]];
    }
    tableau=Array.from({length:7},()=>[]);
    for (let col=0;col<7;col++) {
      for (let row=0;row<=col;row++) {
        const card=deck.pop();
        card.up=(row===col);
        tableau[col].push(card);
      }
    }
    stock=deck.map(c=>({...c,up:false}));
    waste=[]; foundations=[[],[],[],[]];
    selected=null; moves=0; won=false;
    if (history) history.clear();
  }

  function flipTops() {
    for (const col of tableau)
      if (col.length&&!col[col.length-1].up) col[col.length-1].up=true;
  }
  function checkWin() { won=foundations.every(f=>f.length===13); }

  function getStack() {
    if (!selected) return [];
    if (selected.source==='waste') return [waste[waste.length-1]];
    return tableau[selected.col].slice(selected.cardIdx);
  }
  function removeSelected() {
    if (!selected) return;
    if (selected.source==='waste') waste.pop();
    else tableau[selected.col].splice(selected.cardIdx);
  }

  function clickStock() {
    selected=null;
    commitMove('Draw / recycle stock', () => {
      if (!stock.length) { stock=[...waste].reverse().map(c=>({...c,up:false})); waste=[]; }
      else { const c=stock.pop(); c.up=true; waste.push(c); }
      moves++;
    });
    saveState(); render();
  }

  function clickWaste() {
    if (won||!waste.length) return;
    if (selected&&selected.source==='waste') { selected=null; render(); return; }
    if (selected) { selected=null; render(); return; }
    selected={source:'waste',col:-1,cardIdx:waste.length-1};
    render();
  }
  function dblClickWaste() {
    if (won||!waste.length) return;
    selected=null;
    const card=waste[waste.length-1];
    for (let f=0;f<4;f++) {
      if (canFoundation(card,foundations[f])) {
        commitMove('Waste to foundation', () => {
          foundations[f].push(waste.pop()); moves++;
          flipTops(); checkWin();
        });
        saveState(); render(); return;
      }
    }
  }

  function clickFoundation(f) {
    if (won) return;
    if (!selected) return;
    const stack=getStack();
    if (stack.length===1&&canFoundation(stack[0],foundations[f])) {
      commitMove('Move to foundation', () => {
        removeSelected(); foundations[f].push(stack[0]); moves++;
        flipTops(); checkWin();
      });
    }
    selected=null; saveState(); render();
  }

  function clickTableau(col,cardIdx) {
    if (won) return;
    const pile=tableau[col];

    // Empty column
    if (cardIdx===undefined||pile[cardIdx]===undefined) {
      if (selected) {
        const stack=getStack();
        if (stack.length&&stack[0].r==='K') {
          commitMove('Move King to empty column', () => {
            removeSelected(); tableau[col].push(...stack); moves++;
            flipTops(); checkWin();
          });
        }
        selected=null;
      }
      saveState(); render(); return;
    }

    const card=pile[cardIdx];
    if (!card.up) { selected=null; render(); return; }

    if (selected) {
      // Deselect same card
      if (selected.source==='tableau'&&selected.col===col&&selected.cardIdx===cardIdx) {
        selected=null; render(); return;
      }
      const stack=getStack();
      if (stack.length&&canTableau(stack[0],col)) {
        commitMove('Tableau to tableau', () => {
          removeSelected(); tableau[col].push(...stack); moves++;
          flipTops(); checkWin();
        });
        selected=null;
        saveState(); render(); return;
      }
      selected=null;
    }
    selected={source:'tableau',col,cardIdx};
    render();
  }

  function dblClickTableau(col,cardIdx) {
    if (won) return;
    const pile=tableau[col];
    if (cardIdx!==pile.length-1) return;
    const card=pile[cardIdx];
    if (!card||!card.up) return;
    selected=null;
    for (let f=0;f<4;f++) {
      if (canFoundation(card,foundations[f])) {
        commitMove('Tableau to foundation', () => {
          foundations[f].push(pile.pop()); moves++;
          flipTops(); checkWin();
        });
        saveState(); render(); return;
      }
    }
  }

  function autoFoundation() {
    commitMove('Auto play', () => {
      let moved=true;
      while (moved) {
        moved=false;
        if (waste.length) {
          const c=waste[waste.length-1];
          for (let f=0;f<4;f++) {
            if (canFoundation(c,foundations[f])) { foundations[f].push(waste.pop()); moved=true; moves++; break; }
          }
        }
        for (let col=0;col<7;col++) {
          if (!tableau[col].length) continue;
          const c=tableau[col][tableau[col].length-1];
          if (!c.up) continue;
          for (let f=0;f<4;f++) {
            if (canFoundation(c,foundations[f])) { foundations[f].push(tableau[col].pop()); moved=true; moves++; break; }
          }
        }
      }
      flipTops(); checkWin();
    });
    selected=null; saveState(); render();
  }

  // ── Render ─────────────────────────────────────────────────────────────────
  function makeCardEl(card,sel) {
    const el=document.createElement('div');
    el.className='sol-card'+(isRed(card)?' sol-red':'')+(sel?' sol-sel-card':'');
    el.innerHTML=`<span class="sol-rank">${card.r}</span><span class="sol-suit">${card.s}</span>`;
    return el;
  }
  function makeBackEl() {
    const el=document.createElement('div'); el.className='sol-card sol-back'; return el;
  }
  function makeEmptyEl(label) {
    const el=document.createElement('div'); el.className='sol-empty';
    if (label) el.textContent=label; return el;
  }

  function render() {
    if (!container) return;
    container.querySelector('.sol-moves').textContent=`Moves: ${moves}`;
    const winEl=container.querySelector('.sol-win');
    if (winEl) winEl.style.display=won?'block':'none';

    const undoBtn=container.querySelector('#sol-undo');
    const redoBtn=container.querySelector('#sol-redo');
    if (undoBtn) undoBtn.disabled=!history||!history.canUndo();
    if (redoBtn) redoBtn.disabled=!history||!history.canRedo();

    // Stock
    const stockEl=container.querySelector('.sol-stock');
    if (stockEl) {
      stockEl.innerHTML='';
      const c=stock.length?makeBackEl():makeEmptyEl('↺');
      if (!stock.length) c.classList.add('sol-stock-empty');
      stockEl.appendChild(c);
    }

    // Waste
    const wasteEl=container.querySelector('.sol-waste');
    if (wasteEl) {
      wasteEl.innerHTML='';
      if (waste.length) {
        const card=waste[waste.length-1];
        const sel=selected&&selected.source==='waste';
        wasteEl.appendChild(makeCardEl(card,sel));
      } else {
        wasteEl.appendChild(makeEmptyEl());
      }
    }

    // Foundations
    for (let f=0;f<4;f++) {
      const fEl=container.querySelector(`.sol-foundation[data-f="${f}"]`);
      if (!fEl) continue;
      fEl.innerHTML='';
      if (foundations[f].length) {
        const top=foundations[f][foundations[f].length-1];
        fEl.appendChild(makeCardEl(top,false));
      } else {
        const hint=document.createElement('span');
        hint.className='sol-foundation-hint'; hint.textContent=SUITS[f];
        fEl.appendChild(hint);
      }
    }

    // Tableau columns — use a relative container with absolutely-positioned cards
    for (let col=0;col<7;col++) {
      const colEl=container.querySelector(`.sol-col[data-col="${col}"]`);
      if (!colEl) continue;
      colEl.innerHTML='';

      if (!tableau[col].length) {
        const emp=makeEmptyEl();
        emp.style.cssText='width:46px;height:66px;';
        emp.addEventListener('click',()=>clickTableau(col,undefined));
        colEl.style.height='66px';
        colEl.appendChild(emp); continue;
      }

      // Each face-down card = 14px peek, face-up = 20px peek, last card full height 66px
      const BACK_H=14, FACE_H=20, CARD_H=66;
      let top=0;
      tableau[col].forEach((card,idx)=>{
        const isLast=(idx===tableau[col].length-1);
        const inStack=selected&&selected.source==='tableau'&&selected.col===col&&idx>=selected.cardIdx;
        const el=document.createElement('div');
        el.style.cssText=`position:absolute;top:${top}px;left:0;width:46px;z-index:${idx+1};`;

        if (card.up) {
          el.className='sol-card'+(isRed(card)?' sol-red':'')+(inStack?' sol-sel-card':'');
          el.innerHTML=`<span class="sol-rank">${card.r}</span><span class="sol-suit">${card.s}</span>`;
          el.addEventListener('click',(e)=>{e.stopPropagation();clickTableau(col,idx);});
          el.addEventListener('dblclick',(e)=>{e.stopPropagation();dblClickTableau(col,idx);});
        } else {
          el.className='sol-card sol-back';
          el.addEventListener('click',(e)=>{e.stopPropagation();clickTableau(col,idx);});
        }
        colEl.appendChild(el);
        top+=isLast?0:(card.up?FACE_H:BACK_H);
      });
      colEl.style.height=(top+CARD_H)+'px';
    }
  }

  async function init(el) {
    container=el;
    container.innerHTML=`
      <div class="sol-topbar">
        <span class="sol-moves">Moves: 0</span>
        <div class="sol-topbar-actions">
          <button class="sol-history-btn" id="sol-undo" title="Undo (Ctrl+Z)">↩ Undo</button>
          <button class="sol-history-btn" id="sol-redo" title="Redo (Ctrl+Y)">↪ Redo</button>
          <button class="sol-auto-btn" id="sol-auto">Auto ♠</button>
        </div>
      </div>
      <div class="sol-top-row">
        <div class="sol-stock"></div>
        <div class="sol-waste"></div>
        <div class="sol-spacer"></div>
        <div class="sol-foundation" data-f="0"></div>
        <div class="sol-foundation" data-f="1"></div>
        <div class="sol-foundation" data-f="2"></div>
        <div class="sol-foundation" data-f="3"></div>
      </div>
      <div class="sol-tableau-area">
        <div class="sol-col" data-col="0"></div>
        <div class="sol-col" data-col="1"></div>
        <div class="sol-col" data-col="2"></div>
        <div class="sol-col" data-col="3"></div>
        <div class="sol-col" data-col="4"></div>
        <div class="sol-col" data-col="5"></div>
        <div class="sol-col" data-col="6"></div>
      </div>
      <div class="sol-win" style="display:none">🎉 You Win! 🎉</div>
      <div class="sol-footer">
        <button class="btn-reset" id="btn-reset-sol">New Game</button>
        <div class="game-hint">Click to select · Click destination to move · Double-click → foundation · Ctrl+Z to undo</div>
      </div>
    `;

    container.querySelector('.sol-stock').addEventListener('click',clickStock);
    const w=container.querySelector('.sol-waste');
    w.addEventListener('click',clickWaste);
    w.addEventListener('dblclick',dblClickWaste);
    for (let f=0;f<4;f++)
      container.querySelector(`.sol-foundation[data-f="${f}"]`).addEventListener('click',()=>clickFoundation(f));
    container.querySelector('#sol-auto').addEventListener('click',autoFoundation);
    container.querySelector('#btn-reset-sol').addEventListener('click',reset);
    container.querySelector('#sol-undo').addEventListener('click',doUndo);
    container.querySelector('#sol-redo').addEventListener('click',doRedo);

    // Solitaire is in popup.js's MOUSE_ONLY set, so the central keydown
    // router never calls onKey() for this game. Ctrl+Z/Ctrl+Y are scoped
    // here instead, and only act while the Solitaire pane is the active one.
    if (!history) {
      // Defensive: undo/redo is an enhancement and must never be able to
      // break the core game loop (load/save/render). If history.js wasn't
      // loaded (e.g. missing <script> tag or load-order issue), fall back
      // to a harmless no-op history instead of letting commitMove() throw
      // partway through a move — that previously left state mutated but
      // saveState()/render() never reached.
      try {
        history = HistoryManager.create({maxSize:200});
      } catch (e) {
        console.error('Solitaire: HistoryManager unavailable — undo/redo disabled. '+
          'Make sure <script src="js/history.js"> is included before solitaire.js.', e);
      }
      if (!history) {
        history = {push(){},undo(){return null;},redo(){return null;},canUndo(){return false;},canRedo(){return false;},clear(){}};
      }
      document.addEventListener('keydown',(e)=>{
        if (!container.classList.contains('active')) return;
        const z=e.key.toLowerCase()==='z', y=e.key.toLowerCase()==='y';
        if ((e.ctrlKey||e.metaKey)&&z&&!e.shiftKey) { e.preventDefault(); doUndo(); }
        else if ((e.ctrlKey||e.metaKey)&&(y||(z&&e.shiftKey))) { e.preventDefault(); doRedo(); }
      });
    }

    const resumed=await loadState();
    if (!resumed) startNew();
    render();
  }

  async function reset() { await Storage.remove(STORAGE_KEY); startNew(); render(); }
  function onKey() {}
  return {init,onKey,reset};
})();
