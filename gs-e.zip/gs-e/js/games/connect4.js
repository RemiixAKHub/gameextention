// connect4.js — Full Connect 4 implementation with AI opponent
// Left/Right: move column cursor, Space/Down/Enter: drop piece.

const GameConnect4 = (() => {
  const STORAGE_KEY = 'game_connect4';
  const ROWS = 6, COLS = 7;

  let board = [];    // ROWS x COLS, 0=empty, 1=human, 2=AI
  let cursor = 3;    // column cursor (0-based)
  let turn = 1;      // 1 = human, 2 = AI
  let winner = 0;    // 0=none, 1=human, 2=AI, -1=draw
  let winCells = []; // winning cell coords
  let vsAI = true;
  let container = null;

  // ── State ────────────────────────────────────────────────────────────────

  function serialize() {
    return { board, cursor, turn, winner, winCells, vsAI };
  }

  async function saveState() {
    Storage.saveLazy(STORAGE_KEY, serialize());
  }

  async function loadState() {
    const s = await Storage.load(STORAGE_KEY);
    if (s && s.board) {
      board = s.board; cursor = s.cursor; turn = s.turn;
      winner = s.winner; winCells = s.winCells || []; vsAI = s.vsAI ?? true;
      return true;
    }
    return false;
  }

  // ── Board logic ──────────────────────────────────────────────────────────

  function emptyBoard() {
    return Array.from({ length: ROWS }, () => Array(COLS).fill(0));
  }

  function drop(col, player) {
    for (let r = ROWS - 1; r >= 0; r--) {
      if (board[r][col] === 0) { board[r][col] = player; return r; }
    }
    return -1; // column full
  }

  function checkWin(player) {
    const dirs = [[0,1],[1,0],[1,1],[1,-1]];
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        if (board[r][c] !== player) continue;
        for (const [dr, dc] of dirs) {
          const cells = [[r, c]];
          for (let i = 1; i < 4; i++) {
            const nr = r + dr * i, nc = c + dc * i;
            if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS || board[nr][nc] !== player) break;
            cells.push([nr, nc]);
          }
          if (cells.length === 4) return cells;
        }
      }
    }
    return null;
  }

  function isDraw() {
    return board[0].every(v => v !== 0);
  }

  // ── AI (minimax with alpha-beta, depth 6) ─────────────────────────────

  function scoreWindow(window, player) {
    const opp = player === 2 ? 1 : 2;
    const pc = window.filter(v => v === player).length;
    const ec = window.filter(v => v === 0).length;
    const oc = window.filter(v => v === opp).length;
    if (pc === 4) return 100;
    if (pc === 3 && ec === 1) return 5;
    if (pc === 2 && ec === 2) return 2;
    if (oc === 3 && ec === 1) return -4;
    return 0;
  }

  function scoreBoard(b, player) {
    let score = 0;
    // Center column preference
    const centerCol = b.map(r => r[3]).filter(v => v === player).length;
    score += centerCol * 3;
    // Horizontal
    for (let r = 0; r < ROWS; r++)
      for (let c = 0; c <= COLS - 4; c++)
        score += scoreWindow([b[r][c], b[r][c+1], b[r][c+2], b[r][c+3]], player);
    // Vertical
    for (let c = 0; c < COLS; c++)
      for (let r = 0; r <= ROWS - 4; r++)
        score += scoreWindow([b[r][c], b[r+1][c], b[r+2][c], b[r+3][c]], player);
    // Diagonal
    for (let r = 0; r <= ROWS - 4; r++)
      for (let c = 0; c <= COLS - 4; c++) {
        score += scoreWindow([b[r][c], b[r+1][c+1], b[r+2][c+2], b[r+3][c+3]], player);
        score += scoreWindow([b[r+3][c], b[r+2][c+1], b[r+1][c+2], b[r][c+3]], player);
      }
    return score;
  }

  function getValidCols(b) {
    return [...Array(COLS).keys()].filter(c => b[0][c] === 0);
  }

  function dropTemp(b, col, player) {
    const nb = b.map(r => [...r]);
    for (let r = ROWS - 1; r >= 0; r--) {
      if (nb[r][col] === 0) { nb[r][col] = player; return nb; }
    }
    return nb;
  }

  function isTerminal(b) {
    const checkB = (p) => {
      const dirs = [[0,1],[1,0],[1,1],[1,-1]];
      for (let r = 0; r < ROWS; r++)
        for (let c = 0; c < COLS; c++) {
          if (b[r][c] !== p) continue;
          for (const [dr, dc] of dirs) {
            let count = 0;
            for (let i = 0; i < 4; i++) {
              const nr = r+dr*i, nc = c+dc*i;
              if (nr>=0 && nr<ROWS && nc>=0 && nc<COLS && b[nr][nc]===p) count++;
              else break;
            }
            if (count === 4) return true;
          }
        }
      return false;
    };
    return checkB(1) || checkB(2) || getValidCols(b).length === 0;
  }

  function minimax(b, depth, alpha, beta, maximizing) {
    if (depth === 0 || isTerminal(b)) return { score: scoreBoard(b, 2) - scoreBoard(b, 1) };
    const cols = getValidCols(b);
    if (maximizing) {
      let best = -Infinity, bestCol = cols[0];
      for (const c of cols) {
        const nb = dropTemp(b, c, 2);
        const { score } = minimax(nb, depth - 1, alpha, beta, false);
        if (score > best) { best = score; bestCol = c; }
        alpha = Math.max(alpha, best);
        if (alpha >= beta) break;
      }
      return { score: best, col: bestCol };
    } else {
      let best = Infinity, bestCol = cols[0];
      for (const c of cols) {
        const nb = dropTemp(b, c, 1);
        const { score } = minimax(nb, depth - 1, alpha, beta, true);
        if (score < best) { best = score; bestCol = c; }
        beta = Math.min(beta, best);
        if (alpha >= beta) break;
      }
      return { score: best, col: bestCol };
    }
  }

  function aiMove() {
    const { col } = minimax(board, 5, -Infinity, Infinity, true);
    const c = col ?? getValidCols(board)[0];
    drop(c, 2);
    const w = checkWin(2);
    if (w) { winner = 2; winCells = w; }
    else if (isDraw()) winner = -1;
    turn = 1;
    saveState();
    render();
  }

  // ── Player action ─────────────────────────────────────────────────────────

  function playerDrop() {
    if (winner !== 0 || turn !== 1) return;
    if (board[0][cursor] !== 0) return; // column full
    drop(cursor, 1);
    const w = checkWin(1);
    if (w) { winner = 1; winCells = w; saveState(); render(); return; }
    if (isDraw()) { winner = -1; saveState(); render(); return; }
    turn = 2;
    render();
    setTimeout(() => { aiMove(); }, 200);
  }

  // ── Rendering ────────────────────────────────────────────────────────────

  function render() {
    if (!container) return;
    const info = container.querySelector('.c4-info');
    if (winner === 1) info.textContent = 'You win! 🎉';
    else if (winner === 2) info.textContent = 'AI wins!';
    else if (winner === -1) info.textContent = "It's a draw!";
    else info.textContent = turn === 1 ? 'Your turn' : 'AI thinking...';

    // Cursor arrow
    const arrows = container.querySelectorAll('.c4-arrow');
    arrows.forEach((a, i) => a.classList.toggle('c4-arrow-active', i === cursor));

    const cells = container.querySelectorAll('.c4-cell');
    cells.forEach((cell, idx) => {
      const r = Math.floor(idx / COLS), c = idx % COLS;
      const v = board[r][c];
      cell.className = 'c4-cell';
      if (v === 1) cell.classList.add('c4-p1');
      else if (v === 2) cell.classList.add('c4-p2');
      if (winCells.some(([wr, wc]) => wr === r && wc === c)) cell.classList.add('c4-win');
    });
  }

  // ── Public API ───────────────────────────────────────────────────────────

  async function init(el) {
    container = el;

    let html = '<div class="c4-info"></div>';
    // Arrow row
    html += '<div class="c4-arrows">';
    for (let c = 0; c < COLS; c++) html += `<div class="c4-arrow">▼</div>`;
    html += '</div>';
    // Board
    html += '<div class="c4-board">';
    for (let r = 0; r < ROWS; r++)
      for (let c = 0; c < COLS; c++)
        html += `<div class="c4-cell" data-r="${r}" data-c="${c}"></div>`;
    html += '</div>';
    html += '<button class="btn-reset" id="btn-reset-c4">New Game</button>';
    html += '<div class="game-hint">←→: move column &nbsp; Space/↓: drop</div>';
    container.innerHTML = html;

    // Click to drop
    container.querySelector('.c4-board').addEventListener('click', (e) => {
      const cell = e.target.closest('.c4-cell');
      if (!cell) return;
      cursor = parseInt(cell.dataset.c);
      playerDrop();
    });

    container.querySelector('#btn-reset-c4').addEventListener('click', reset);

    const resumed = await loadState();
    if (!resumed) startNew();
    render();
  }

  function startNew() {
    board = emptyBoard();
    cursor = 3; turn = 1; winner = 0; winCells = [];
  }

  async function reset() {
    await Storage.remove(STORAGE_KEY);
    startNew();
    render();
  }

  function onKey(e) {
    if (!container || winner !== 0) return;
    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      cursor = Math.max(0, cursor - 1); render();
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      cursor = Math.min(COLS - 1, cursor + 1); render();
    } else if (e.key === ' ' || e.key === 'ArrowDown' || e.key === 'Enter') {
      e.preventDefault();
      playerDrop();
    }
  }

  return { init, onKey, reset };
})();
